const { gate } = require("../lib/fb.js");
// Netlify Function: /api/tts
// Calls OpenAI Text-to-Speech API using the server-side OPENAI_API_KEY
// Returns audio/mpeg directly so the browser can play it

exports.handler = async function (event) {
  // Only allow POST
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  // only signed-in people with an active free trial or subscription can use the AI (protects your OpenAI bill)
  const g = await gate(event);
  if (g.error) return g.error;



  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, body: JSON.stringify({ error: "OpenAI API key not configured" }) };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
  }

  const VOICES = ["nova", "shimmer", "coral", "sage", "alloy", "ash", "fable", "echo", "onyx"];
  const STYLES = {
    story: "Read like a warm, engaging storyteller reading a book aloud to a student. Natural pacing, gentle expression, clear pauses at punctuation.",
    calm: "Read slowly in a calm, soft, soothing voice, like a bedtime story. Relaxed pacing with gentle pauses.",
    teacher: "Read like a clear, friendly teacher. Pronounce every word carefully at a steady pace and stress important words.",
    lively: "Read with lively, expressive energy and enthusiasm, while staying clear and easy to follow.",
    plain: "Read in a natural, neutral narration voice at a steady pace."
  };
  const style = STYLES[body.style] ? body.style : "";
  const text = String(body.text || "").slice(0, style ? 900 : 500); // limit length
  const voice = VOICES.includes(body.voice) ? body.voice : "nova"; // nova sounds friendly/young
  // Smart Reader asks for a reading style -> use the steerable model; word cards keep the fast, cheap one
  const model = style ? "gpt-4o-mini-tts" : "tts-1";

  if (!text) {
    return { statusCode: 400, body: JSON.stringify({ error: "No text provided" }) };
  }

  try {
    const speech = payload => fetch("https://api.openai.com/v1/audio/speech", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });
    let response = await speech(Object.assign({ model, voice, input: text, response_format: "mp3" }, style ? { instructions: STYLES[style] } : {}));
    // If the steerable model isn't available on this account, fall back to the classic voice model
    if (!response.ok && style && response.status !== 429) {
      response = await speech({ model: "tts-1", voice, input: text.slice(0, 900), response_format: "mp3" });
    }

    if (!response.ok) {
      const err = await response.text();
      return { statusCode: response.status, body: JSON.stringify({ error: err }) };
    }

    // Read the audio bytes and return as base64
    const audioBuffer = await response.arrayBuffer();
    const base64Audio = Buffer.from(audioBuffer).toString("base64");

    return {
      statusCode: 200,
      headers: { "Content-Type": "audio/mpeg", "Cache-Control": "no-store" },
      body: base64Audio,
      isBase64Encoded: true
    };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
};
